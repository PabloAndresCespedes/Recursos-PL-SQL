'use strict';

module.exports = {
	user: "demo_ords",
	password: "oracle",
	connectString: "localhost/orcl",
};